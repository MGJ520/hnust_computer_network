//time:2024.1.4
//coder:MGJ
#include <iostream>
#include<map>
#include <conio.h>
#include <windows.h>

using namespace std;
//��������
#define MENUNUMS1 4
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//��������
void cls();

void Init_data();

int Menuchoose1();

void Menushow1(int i);

void Function_Select(int select);

void Net_address_translation();

void Net_address_add();

void Net_address_delect();

void Net_address_revise();

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
map<string, string> Maps_In;
map<string, string> Maps_Out;
//----------------------------------------------------------------------------------
//������
int main() {
    int out = 0;
    Init_data();
    while (true) {
        out = Menuchoose1();
        Function_Select(out);
    }
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//��ʼ������
void Init_data() {
    Maps_In["172.38.1.5:40001"] = "192.168.0.3:30000";
    Maps_In["172.38.1.5:40002"] = "192.168.0.4:30000";
    Maps_Out["192.168.0.3:30000"] = "172.38.1.5:40001";
    Maps_Out["192.168.0.4:30000"] = "172.38.1.5:40002";
}

//ѡ����
int Menuchoose1() {
    int ch, i = 0;
    Menushow1(0);
    while (true) {
        if (_kbhit()) {
            ch = _getch();
            if (ch == 80) {
                //ѭ��
                i = (++i) % MENUNUMS1;
                Menushow1(i);
            } else if (ch == 72) {
                //ѭ����ֹ���ָ���
                i = ((--i) + MENUNUMS1) % MENUNUMS1;
                Menushow1(i);
            } else if (ch == 13) return i + 1;
        }
    }
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//�˵���ʾ
void Menushow1(int i) {
    cls();
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),
                            FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
    cout << "\n *=====ģ�� NAT �����ַת��Demo=====*\n";
    if (i == 0)SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), BACKGROUND_RED);
    cout << "          ->>>ת�������ַ<<<-        " << endl;
    if (i == 1)SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), BACKGROUND_RED);
    if (i == 0)
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),
                                FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
    cout << "          ->>>���������ַ<<<-        " << endl;
    if (i == 2)SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), BACKGROUND_RED);
    if (i == 1)
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),
                                FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
    cout << "          ->>>ɾ�������ַ<<<-        " << endl;
    if (i == 3)SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), BACKGROUND_RED);
    if (i == 2)
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),
                                FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
    cout << "          ->>>�޸������ַ<<<-        " << endl;
    if (i == 3)
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),
                                FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
    cout << " -------------------------------------\n";
}

//���ܺ���
void Function_Select(int select) {
    switch (select) {
        case 1: {
            Net_address_translation();
            break;
        }
        case 2: {
            Net_address_add();
            break;
        }
        case 3: {
            Net_address_delect();
            break;
        }
        case 4: {
            Net_address_revise();
            break;
        }
    }
    system("cls");
}

void Net_address_translation() {
    string Search_addrs;
    cout << "������IP��˿�(����:172.38.1.5:40001):" << endl;
    cin >> Search_addrs;
    cout << endl << " ת�����Ϊ:--------------------------------" << endl << endl;
    if (Maps_In.find(Search_addrs) == Maps_In.end() && Maps_Out.find(Search_addrs) == Maps_Out.end()) {
        cout << " * ϵͳû�д˵�ַIP *" << endl;
    } else if (Maps_In.find(Search_addrs) != Maps_In.end()) {
        cout << "  �ڲ���ַ: " << Maps_In[Search_addrs] << endl;
    } else if (Maps_Out.find(Search_addrs) != Maps_Out.end()) {
        cout << "  �ⲿ��ַ:" << Maps_Out[Search_addrs] << endl;
    }
    cout << endl << " -------------------------------------------" << endl;
    system("pause");
}

void Net_address_add() {
    string Input_interior_addrs;
    string Input_exterior_addrs;
    cout << "�������ڲ���ַ(����:172.38.1.5:40001):" << endl;
    cin >> Input_interior_addrs;
    cout << "�������ⲿ��ַ(����:172.38.1.5:40001):" << endl;
    cin >> Input_exterior_addrs;
    cout << endl << " ������Ϊ:--------------------------------" << endl << endl;
    cout << "  �ڲ���ַ:" << Input_interior_addrs << endl;
    cout << "  �ⲿ��ַ:" << Input_exterior_addrs << endl;
    cout << endl << " -------------------------------------------" << endl;
    Maps_In[Input_exterior_addrs] = Input_interior_addrs;
    Maps_Out[Input_interior_addrs] = Input_exterior_addrs;
    system("pause");
}

void Net_address_delect() {
    string Search_addrs;
    cout << "��������Ҫɾ����IP��˿�(����:172.38.1.5:40001):" << endl;
    cin >> Search_addrs;
    cout << endl << " ɾ�����Ϊ:--------------------------------" << endl << endl;
    if (Maps_In.find(Search_addrs) == Maps_In.end() && Maps_Out.find(Search_addrs) == Maps_Out.end()) {
        cout << " * ϵͳû�д˵�ַIP *" << endl;
    } else if (Maps_In.find(Search_addrs) != Maps_In.end()) {
        cout << "  �ڲ���ַ: " << Maps_In[Search_addrs] << endl;
        cout << "  �ⲿ��ַ: " << Search_addrs<< endl;
        Maps_Out.erase(Maps_In[Search_addrs]);
        Maps_In.erase(Search_addrs);
    } else if (Maps_Out.find(Search_addrs) != Maps_Out.end()) {
        cout << "  �ڲ���ַ: " << Search_addrs<< endl;
        cout << "  �ⲿ��ַ: " << Maps_Out[Search_addrs] << endl;
        Maps_In.erase(Maps_Out[Search_addrs]);
        Maps_Out.erase(Search_addrs);
    }
    cout << endl << " -------------------------------------------" << endl;
    system("pause");
}

void Net_address_revise() {
    string Search_addrs;
    string Input__addrs;
    cout << "��������Ҫ�޸ĵ�IP��˿�(����:172.38.1.5:40001):" << endl;
    cin >> Search_addrs;
    cout << endl << " ��ǰ���Ϊ:--------------------------------" << endl << endl;
    if (Maps_In.find(Search_addrs) == Maps_In.end() && Maps_Out.find(Search_addrs) == Maps_Out.end()) {
        cout << " * ϵͳû�д˵�ַIP *" << endl;
        cout << endl << " -------------------------------------------" << endl;
        system("pause");
        return;
    } else if (Maps_In.find(Search_addrs) != Maps_In.end()) {
        cout << "  �ڲ���ַ: " << Maps_In[Search_addrs] << endl;
        cout << "  �ⲿ��ַ: " << Search_addrs<< endl;
        cout << endl << " -------------------------------------------" << endl;
        cout << "���޸��ڲ���IP��˿�(����:172.38.1.5:40001):" << endl,cin>>Input__addrs;;
        Maps_In[Search_addrs]=Input__addrs;
    } else if (Maps_Out.find(Search_addrs) != Maps_Out.end()) {
        cout << "  �ڲ���ַ: " << Search_addrs<< endl;
        cout << "  �ⲿ��ַ: " << Maps_Out[Search_addrs] << endl;
        cout << endl << " -------------------------------------------" << endl;
        cout << "���޸��ⲿ��IP��˿�(����:172.38.1.5:40001):" << endl,cin>>Input__addrs;;
        Maps_Out[Search_addrs]=Input__addrs;
    }
    cout << endl << " -------------------------------------------" << endl;
    system("pause");
}
//��������
void cls() {
    COORD pos;
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    pos.Y = pos.X = 0;
    SetConsoleCursorPosition(hOut, pos);
}
