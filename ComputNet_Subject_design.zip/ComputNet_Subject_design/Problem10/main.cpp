//time:2024.1.4
//coder:MGJ

//ע��
//https://baijiahao.baidu.com/s?id=1683531102064675651
//Demo��Ŀ

#include <iostream>
#include <conio.h>
#include <windows.h>
#include <vector>
#include <sstream>

using namespace std;
//�˵���������
#define MENUNUMS1 4
//·�ɱ��������
#define Router_max_num 128

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//��������
void cls();

void Init_data();

int Menuchoose1();

void Menushow1(int i);

void Function_Select(int select);

void Net_address_translation();

void Net_address_add();

void Net_address_delect();

void Net_address_revise();

void Stringsplit(string str, const char split, vector<string> &res);

void Net_Map_Show();

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//·�ɱ�
struct Router_Map {
    //Ŀ�������ַ���������룬��һ��
    int Destination_network_address[4] = {0};
    int Subnet_mask[4] = {0};
    string Next_hop;

    BOOLEAN Init_Router_Map(string ip,string mask,string Next_hop)
    {
        if (ip=="n"|| mask=="n"||Next_hop=="n") return false;
        Set_Router_Map_Destination_add(ip);
        Set_Router_Map_mask_add(mask);
        this->Next_hop=Next_hop;
        return true;
    }

    void Set_Router_Map_Destination_add(string ip) {
        vector<string> strList;
        int num = 0, i = 0;
        Stringsplit(ip, '.', strList);     // ���Ӵ���ŵ�strList��
        for (auto str_num: strList) {
            istringstream ss(str_num);
            ss >> num;
            Destination_network_address[i++] = num;
        }
    }

    void Set_Router_Map_mask_add(string mask) {
        vector<string> strList;
        int num = 0, i = 0;
        Stringsplit(mask, '.', strList);    // ���Ӵ���ŵ�strList��
        for (auto str_num: strList) {
            istringstream ss(str_num);
            ss >> num;
            Subnet_mask[i++] = num;
        }
    }
};

Router_Map Router_Map_Data[Router_max_num];//�����洢��
int Now_Router_Num = 0;//��ǰ�ı���С
//----------------------------------------------------------------------------------
//������
int main() {
    int out = 0;
    Init_data();
    while (true) {
        out = Menuchoose1();
        Function_Select(out);
    }
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//��ʼ������
void Init_data() {
    //0λΪĬ������/�ⲿ����(������)
    Router_Map_Data[0].Init_Router_Map("0.0.0.0"  ,"255.255.255.255","R4");
    //������������޸�����
    Router_Map_Data[1].Init_Router_Map("128.96.39.0"  ,"255.255.255.128","�ӿ�M0");
    Router_Map_Data[2].Init_Router_Map("128.96.39.128","255.255.255.128","�ӿ�M1");
    Router_Map_Data[3].Init_Router_Map("128.96.40.0"  ,"255.255.255.128","R2");
    Router_Map_Data[4].Init_Router_Map("192.4.153.0"  ,"255.255.255.192","R3");
    Now_Router_Num = 4;//1-4 ���������
}

//ѡ����
int Menuchoose1() {
    int ch, i = 0;
    Menushow1(0);
    while (true) {
        if (_kbhit()) {
            ch = _getch();
            if (ch == 80) {
                //ѭ��
                i = (++i) % MENUNUMS1;
                Menushow1(i);
            } else if (ch == 72) {
                //ѭ����ֹ���ָ���
                i = ((--i) + MENUNUMS1) % MENUNUMS1;
                Menushow1(i);
            } else if (ch == 13) return i + 1;
        }
    }
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//�˵���ʾ
void Menushow1(int i) {
    cls();
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
    cout << "\n *===== ·�����������ģ�� Demo=====*\n";
    if (i == 0)SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), BACKGROUND_RED);
    cout << "          ->>>��ѯ��ַȥ��<<<-        " << endl;
    if (i == 1)SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), BACKGROUND_RED);
    if (i == 0)SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),
                                FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
    cout << "          ->>>����·�ɵ�ַ<<<-        " << endl;
    if (i == 2)SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), BACKGROUND_RED);
    if (i == 1)SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),
                                FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
    cout << "          ->>>ɾ��·�ɵ�ַ<<<-        " << endl;
    if (i == 3)SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), BACKGROUND_RED);
    if (i == 2) SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
    cout << "          ->>>�޸�·�ɵ�ַ<<<-        " << endl;
    if (i == 3)    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),FOREGROUND_INTENSITY | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE);
    cout << " -------------------------------------\n";
}

//���ܺ���
void Function_Select(int select) {
    Net_Map_Show();
    switch (select) {
        case 1: {
            Net_address_translation();
            break;
        }
        case 2: {
            Net_address_add();
            break;
        }
        case 3: {
            Net_address_delect();
            break;
        }
        case 4: {
            Net_address_revise();
            break;
        }
    }
    system("pause");
    system("cls");
}
void Net_Map_Show() {
    cout << "\t���\tĿ�ĵ�ַ\t\t����\t\t��һ��" << endl;
    for (int i = 0; i <= Now_Router_Num; ++i) {
        cout << "  \t "<<i<<"\t";
        for (int j = 0; j < 4; ++j) {
            cout << Router_Map_Data[i].Destination_network_address[j];
            j != 3 ? cout << "." : cout << "  \t";
        }
        for (int j = 0; j < 4; ++j) {
            cout << Router_Map_Data[i].Subnet_mask[j];
            j != 3 ? cout << "." : cout << "\t\t";
        }
        cout << Router_Map_Data[i].Next_hop << endl;
    }
}
void Net_address_translation() {
    int Input_Destination[4] = {0},
        Get_Destination[4]   = {0},
        Cal_num              = 0  ,
        Find_Local           = 0  ;
    cout << "\n�������ѯ��Ŀ�ĵ�ַ(��:128.96.39.10):";
    scanf("%d.%d.%d.%d", &Input_Destination[0], &Input_Destination[1], &Input_Destination[2], &Input_Destination[3]);
    for (int i = 1; i <= Now_Router_Num; ++i) {
        Cal_num = 0;
        for (int j = 0; j < 4; ++j) {
            Get_Destination[j] = Router_Map_Data[i].Subnet_mask[j] & Input_Destination[j];
            Cal_num = Cal_num + (Router_Map_Data[i].Destination_network_address[j] - Get_Destination[j]);
        }
        if (Cal_num == 0) {
            Find_Local = i;
            break;
        }
    }
    cout << endl << " -------------------------------------------" << endl;
    cout << " �������Ŀ�ĵ�ַΪ:";
    for (int j = 0; j < 4; ++j) {
        cout << Get_Destination[j];
        j != 3 ? cout << "." : cout << "\n";
    }
    cout << " ��һ��Ϊ: " << Router_Map_Data[Find_Local].Next_hop << endl;
    cout << " -------------------------------------------" << endl;
}

void Net_address_add() {
    string  input_Destination,
            input_Subnet_mask,
            input_Next_hop   ;
    cout << endl << " -------------(����n��ȡ����ǰ����)-------------" << endl;
    cout<<" ��������Ҫ���ӵ�Ŀ������:",cin>>input_Destination;
    cout<<" ��������Ҫ���ӵ���������:",cin>>input_Subnet_mask;
    cout<<" ��������Ҫ���ӵ���һ��:",cin>>input_Next_hop;
    cout << endl << " -------------------------------------------" << endl;
    if(Router_Map_Data[Now_Router_Num+1].Init_Router_Map(input_Destination,input_Subnet_mask,input_Next_hop))
    Now_Router_Num++;
}

void Net_address_delect() {
    cout << " * ���뿪�������ɾ�����ƶ���doge), �볢���޸İ�" << endl;
}

void Net_address_revise() {
    string  input_Destination,   //12
            input_Subnet_mask,   //123
            input_Next_hop;      //321

    int     input_num;

    cout << endl << " -------------(����n��ȡ����ǰ����)-------------" << endl;
    cout<<" ��������Ҫ�޸ĵ������(0-"<<Now_Router_Num<<"):",cin>>input_num;
    cout<<" �������޸ĵ�Ŀ������:",cin>>input_Destination;
    cout<<" �������޸ĵ���������:",cin>>input_Subnet_mask;
    cout<<" �������޸ĵ���һ��:",cin>>input_Next_hop;
    cout << " -------------------------------------------" << endl;

    Router_Map_Data[input_num].Init_Router_Map(input_Destination,input_Subnet_mask,input_Next_hop);
}

//��������
void cls() {
    COORD pos;
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    pos.Y = pos.X = 0;
    SetConsoleCursorPosition(hOut, pos);
}

//Stringsplit
void Stringsplit(string str, const char split, vector<string> &res) {
    istringstream iss(str);    // ������
    string token;              // ���ջ�����
    while (getline(iss, token, split))    // ��splitΪ�ָ���
    {
        res.push_back(token);
    }
}

