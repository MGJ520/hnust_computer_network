#include<winsock2.h>//winsock2��ͷ�ļ�
#include<iostream>
#include <list>
#include <ctime>

#pragma comment(lib, "ws2_32.lib")

using namespace std;

//����========================
void Init_Socket();

void *SendMsg(void *pVoid);

int getRand(int min, int max);

void Sycn();

void Send_Win_Move();

void Retransmission(int Num);

//���͵�����=======================
struct Data {
    //��Ϣ���Ͷ���
    int Type_ACK = 0;
    int Type_Msg = 1;
    int Type_Requst = 2;
    int Type_Retransmission = 3;
    //��Ϣ����
    int Msg_Code = 0;//��Ϣ���
    int Msg_Type = 1;//��Ϣ����
    int Msg_ACK = 0;//�Ƿ��Ѿ�ACK��
    char *Msg_Content[128];//��Ϣ����
    int Send_WinSize = 4;//���ʹ��ڴ�С
};

//Ĭ�ϲ���=======================
int Rand_Num = 5;//�������1/5
int Receiver_WinSize = 10;
int Send_WinSize = 5;
int Send_Size = 10;
int ACK_OutTime = 10;
int Send_Num = 100;
char *Send_Msg = "0123456789";
SOCKET Socket;
int Win_Now_Size = 0;


//��Ϣ�б�=======================
list<Data> MSG_Win_List;
Data Send_Msg_Data;
Data *Get_Msg_Data;
Data *Temp_Msg_Data;
int Num = 0;
char send_buf[1024] = {0}, Get_buf[1024] = {0};

void init_data() {
    char auto_data;
    //��ʾ=======================================================================
    cout << "*====��������Э�����(Socketģ��)_���ͷ�====*\n";
    cout << "\n-------------------------------\n";
    cout << " �������Ҫ����(y/n):";
    cin >> auto_data;
    if (auto_data == 'n') {
        cout << " ���ʹ���: ", cout << Send_WinSize << endl;
        cout << " ��Ϣ֡��: ", cout << Send_Num << endl;
//        cout << " ��������: ", cout << Send_Msg << endl;
    } else {
        cout << " ���ʹ���: ", cin >> Send_WinSize;
        cout << " ��Ϣ֡��: ", cin >> Send_Num;
    }
    cout << "-------------------------------" << endl;
    system("pause");

}

int main() {
    init_data();
    Init_Socket();
    //���շ���˵���Ϣ
    pthread_t tids;
    pthread_create(&tids, NULL, SendMsg, &Socket);
    //��ʱ������˷���Ϣ
    do {
        int ret = 0;
        do {
            ret = recv(Socket, Get_buf, sizeof(Get_buf), 0);
            Get_Msg_Data = (Data *) Get_buf;
            if (ret != SOCKET_ERROR && ret != 0) {
                cout << "\n\n\t==>�յ�֡:" << " ACK: " << Get_Msg_Data->Msg_Code << endl;
                list<Data>::iterator iter;
                for (iter = MSG_Win_List.begin(); iter != MSG_Win_List.end(); iter++) {
                    if (Get_Msg_Data->Msg_Code == iter->Msg_Code) {
                        (*iter).Msg_ACK = 1;
                        if (Get_Msg_Data->Msg_Type == 3) {
                            cout << "\n\t�ش�ɾ����һ��" << endl;
                            Win_Now_Size--;
                            MSG_Win_List.erase(iter);
                        }
                        break;
                    }
                }
                Sycn();
            }
        } while (ret != SOCKET_ERROR && ret != 0);
    } while (true);
    //�رռ����׽���
    closesocket(Socket);
    WSACleanup();

}

void Init_Socket() {
    WSADATA wd;
    //����winsock2�Ļ���
    if (WSAStartup(MAKEWORD(2, 2), &wd) != 0) {
        cout << "WSAStartup  error��" << GetLastError() << endl;
        return;
    }
    //������ʽ�׽���
    Socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (Socket == INVALID_SOCKET) {
        cout << "socket  error��" << GetLastError() << endl;
        return;
    }
    //���ӷ�����
    sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(8000);
    addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    int len = sizeof(sockaddr_in);
    if (connect(Socket, (SOCKADDR *) &addr, len) == SOCKET_ERROR) {
        cout << "connect  error��" << GetLastError() << endl;
        return;
    }
}

void *SendMsg(void *pVoid) {
    do {
        Send_Win_Move();
        Sycn();
        system("pause");
        Send_Msg_Data.Msg_Code = Num;
        Send_Msg_Data.Msg_Type = 1;
        memcpy(send_buf, &Send_Msg_Data, sizeof(Data));
 if (Win_Now_Size == Send_WinSize) {
     list<Data>::iterator iter;
     for (iter = MSG_Win_List.begin(); iter != MSG_Win_List.end(); iter++) {
         if (iter->Msg_ACK == 0) {
             Send_Msg_Data.Msg_Code = iter->Msg_Code;
             Send_Msg_Data.Msg_Type = 3;
             memcpy(send_buf, &Send_Msg_Data, sizeof(Data));
             if (send(Socket, send_buf, sizeof(send_buf), 0) > 0) {
                 cout << "\n\t<==�����ش�֡:" << iter->Msg_Code << endl;
             } else {
                 cout << "\n\t<==ʧ�ܷ����ش�֡:" << iter->Msg_Code << endl;
             }

             break;
         }
     }
     continue;
 }
        if (getRand(1, Rand_Num) == Rand_Num)//�����ʧ
        {
            cout << "\n\t<=xxxx=�����ʧ֡:" << Num++ << endl;
        } else {
            if (send(Socket, send_buf, sizeof(send_buf), 0) > 0) {
                cout << "\n\t<==����֡:" << Num++ << endl;
            } else {
                cout << "\n\t<<==ʧ�ܷ���֡:" << Num++ << endl;
            }
        }
        Win_Now_Size++;
        Send_Num--;
        MSG_Win_List.push_back(Send_Msg_Data);
    } while (Send_Num > 0);
}
//�����ƶ�����
void Send_Win_Move() {
    if (MSG_Win_List.begin()->Msg_ACK == 0) return;
    list<Data>::iterator iter=MSG_Win_List.begin();
    while (iter->Msg_ACK==1)
    {
        MSG_Win_List.erase(iter);
        Win_Now_Size--;
        iter=MSG_Win_List.begin();
    }
    cout << "\n\t�����ƶ���" << endl;
}

int getRand(int min, int max) {
    return (rand() % (max - min + 1)) + min;
}

void Sycn() {
    cout << "\n\t------------------------------" << endl;
    cout << "\t��ǰ���ʹ���:" << Send_WinSize << "\t���ô��ڴ�С:" << Send_WinSize - Win_Now_Size << endl;
    list<Data>::iterator iter;
    for (iter = MSG_Win_List.begin(); iter != MSG_Win_List.end(); iter++) {
        cout << "\t#֡���:" << iter->Msg_Code << "\t#�Ƿ�ACK:" << iter->Msg_ACK << endl;
    }
    cout << "\t------------------------------" << endl;
}