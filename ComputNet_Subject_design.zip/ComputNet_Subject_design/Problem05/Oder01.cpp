//
// Created by 123 on 2024-1-2.
//
#include<winsock2.h>//winsock2��ͷ�ļ�
#include<iostream>

using namespace std;

void init_app();

#pragma comment(lib, "ws2_32.lib")

SOCKET Socket;

//�ͻ���
int main() {
    init_app();
    //���շ���˵���Ϣ
    do {
        int ret = 0;
        do {
            char buf[100] = {0};
            ret = recv(Socket, buf, 100, 0);
            if(ret != SOCKET_ERROR && ret != 0)
            cout << " �յ��㲥: " << buf << endl;
        } while (ret != SOCKET_ERROR && ret != 0);

    } while (true);
}
void init_app() {
    cout << "===========�ͻ���============" << endl;
    WSADATA wd;
    //����winsock2�Ļ���
    if (WSAStartup(MAKEWORD(2, 2), &wd) != 0) {
        cout << "WSAStartup  error��" << GetLastError() << endl;
        return;
    }
    //������ʽ�׽���
    Socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (Socket == INVALID_SOCKET) {
        cout << "socket  error��" << GetLastError() << endl;
        return;
    }
    //���ӷ�����
    sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(8000);
    addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    int len = sizeof(sockaddr_in);
    if (connect(Socket, (SOCKADDR *) &addr, len) == SOCKET_ERROR) {
        cout << "connect  error��" << GetLastError() << endl;
        return;
    }
}