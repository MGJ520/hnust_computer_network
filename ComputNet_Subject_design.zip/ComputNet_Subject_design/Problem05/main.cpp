//�����
#include <winsock2.h>
#include <iostream>
#include <list>

#pragma comment(lib, "ws2_32.lib")
using namespace std;

// �̴߳�������12
DWORD WINAPI ThreadFun(LPVOID lpThreadParameter);

void init_app();

void Send_All(list<SOCKET> Client_List_Now, char *msg, SOCKET This_Socket);

void *Send_Msg(void *pVoid);

SOCKET Socket;
list<SOCKET> Client_List;
sockaddr_in addrClient;

int len = sizeof(sockaddr_in);


int main() {
    init_app();
    pthread_t tids;
    pthread_create(&tids, NULL, Send_Msg, &Socket);
    //���߳�ѭ�����տͻ��˵�����
    while (true) {
        // ���ܳɹ�������clientͨѶ��Socket
        SOCKET Client = accept(Socket, (SOCKADDR *) &addrClient, &len);
        if (Client != INVALID_SOCKET) {
            // �����̣߳����Ҵ�����clientͨѶ���׽���
            HANDLE hThread = CreateThread(NULL, 0, ThreadFun, (LPVOID) Client, 0, NULL);
            CloseHandle(hThread); // �رն��̵߳�����
        }
    }
}

void *Send_Msg(void *pVoid) {
    char *msg;
    do {
        cout << " ���͹㲥:" ,cin>> msg ;
        Send_All(Client_List, msg, NULL);
    } while (true);
}

DWORD WINAPI ThreadFun(LPVOID lpThreadParameter) {
    // ��������
    SOCKET This_Socket = (SOCKET) lpThreadParameter;
    cout << " "<<This_Socket << "����㲥" << endl;
    Client_List.push_back(This_Socket);

    // ѭ�����տͻ���״̬
    int ret = 0;
    do {

        char buf2[100] = {0};
        ret = recv(This_Socket, buf2, 100, 0);
    } while (ret != SOCKET_ERROR && ret != 0);

    Client_List.remove(This_Socket);
    cout << This_Socket << "����" << endl;
    return 0;
}

void Send_All(list<SOCKET> Client_List_Now, char *msg, SOCKET This_Socket) {
    if (This_Socket != NULL)
        Client_List_Now.remove(This_Socket);
    for (auto iter: Client_List_Now) {
        send(iter, msg, strlen(msg), 0);
    }
}

void init_app() {
    cout << "===========�����============" << endl;
    WSADATA wd;
    if (WSAStartup(MAKEWORD(2, 2), &wd) != 0) {
        cout << "WSAStartup Error:" << WSAGetLastError() << endl;
        return;
    }
    // ������ʽ�׽���
    Socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    if (Socket == INVALID_SOCKET) {
        cout << "socket error:" << WSAGetLastError() << endl;
        return;
    }
    //�󶨶˿ں�ip
    sockaddr_in addr;
    memset(&addr, 0, sizeof(sockaddr_in));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(8000);
    addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    //�����bind��
    if (bind(Socket, (SOCKADDR *) &addr, len) == SOCKET_ERROR) {
        cout << "bind Error:" << WSAGetLastError() << endl;
        return;
    }
    // ����20�������豸
    listen(Socket, 20);
}//�����
#include <winsock2.h>
#include <iostream>
#include <list>

#pragma comment(lib, "ws2_32.lib")
using namespace std;

// �̴߳�������12
DWORD WINAPI ThreadFun(LPVOID lpThreadParameter);

void init_app();

void Send_All(list<SOCKET> Client_List_Now, char *msg, SOCKET This_Socket);

void *Send_Msg(void *pVoid);

SOCKET Socket;
list<SOCKET> Client_List;
sockaddr_in addrClient;

int len = sizeof(sockaddr_in);


int main() {
    init_app();
    pthread_t tids;
    pthread_create(&tids, NULL, Send_Msg, &Socket);
    //���߳�ѭ�����տͻ��˵�����
    while (true) {
        // ���ܳɹ�������clientͨѶ��Socket
        SOCKET Client = accept(Socket, (SOCKADDR *) &addrClient, &len);
        if (Client != INVALID_SOCKET) {
            // �����̣߳����Ҵ�����clientͨѶ���׽���
            HANDLE hThread = CreateThread(NULL, 0, ThreadFun, (LPVOID) Client, 0, NULL);
            CloseHandle(hThread); // �رն��̵߳�����
        }
    }
}

void *Send_Msg(void *pVoid) {
    char *msg;
    do {
        cout << " ���͹㲥:" ,cin>> msg ;
        Send_All(Client_List, msg, NULL);
    } while (true);
}

DWORD WINAPI ThreadFun(LPVOID lpThreadParameter) {
    // ��������
    SOCKET This_Socket = (SOCKET) lpThreadParameter;
    cout << " "<<This_Socket << "����㲥" << endl;
    Client_List.push_back(This_Socket);

    // ѭ�����տͻ���״̬
    int ret = 0;
    do {

        char buf2[100] = {0};
        ret = recv(This_Socket, buf2, 100, 0);
    } while (ret != SOCKET_ERROR && ret != 0);

    Client_List.remove(This_Socket);
    cout << This_Socket << "����" << endl;
    return 0;
}

void Send_All(list<SOCKET> Client_List_Now, char *msg, SOCKET This_Socket) {
    if (This_Socket != NULL)
        Client_List_Now.remove(This_Socket);
    for (auto iter: Client_List_Now) {
        send(iter, msg, strlen(msg), 0);
    }
}

void init_app() {
    cout << "===========�����============" << endl;
    WSADATA wd;
    if (WSAStartup(MAKEWORD(2, 2), &wd) != 0) {
        cout << "WSAStartup Error:" << WSAGetLastError() << endl;
        return;
    }
    // ������ʽ�׽���
    Socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    if (Socket == INVALID_SOCKET) {
        cout << "socket error:" << WSAGetLastError() << endl;
        return;
    }
    //�󶨶˿ں�ip
    sockaddr_in addr;
    memset(&addr, 0, sizeof(sockaddr_in));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(8000);
    addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    //�����bind��
    if (bind(Socket, (SOCKADDR *) &addr, len) == SOCKET_ERROR) {
        cout << "bind Error:" << WSAGetLastError() << endl;
        return;
    }
    // ����20�������豸
    listen(Socket, 20);
}